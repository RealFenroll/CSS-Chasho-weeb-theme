﻿/*
 * Created by SharpDevelop.
 * User: Fenroll
 * Date: 02-Apr-20
 * Time: 8:51 AM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace BGFlag
{
	/// <summary>
	/// Description of MainForm.
	/// </summary>
	public partial class MainForm : Form
	{
		public MainForm()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
			int Random(int x)
		{
			Random rand = new Random();
			int sides=rand.Next(470,521)-x;
			return sides;
		}


		void MainFormPaint(object sender, PaintEventArgs e)
		{
	
		}
		void Panel1Paint(object sender, PaintEventArgs e)
		{
			Graphics g = e.Graphics;
			g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
			
			Random rand = new Random();
			int Side1=rand.Next(450,501);
			int Side2=rand.Next(400,451);
			int Side3=rand.Next(350,401);
			int Side4=rand.Next(300,351);
			int Side5=rand.Next(250,301);
			int Side6=rand.Next(200,251);
			int Side7=rand.Next(150,201);
			int Side8=rand.Next(100,151);
			int Side9=rand.Next(50,101);
			int Side10=rand.Next(0,51);
			
			g.FillRectangle((new SolidBrush(Color.FromArgb(rand.Next(256), rand.Next(256), rand.Next(256)))),(500-Side1)/2,(500-Side1)/2,Side1,Side1);	
			g.FillRectangle((new SolidBrush(Color.FromArgb(rand.Next(256), rand.Next(256), rand.Next(256)))),(500-Side2)/2,(500-Side2)/2,Side2,Side2);
			g.FillRectangle((new SolidBrush(Color.FromArgb(rand.Next(256), rand.Next(256), rand.Next(256)))),(500-Side3)/2,(500-Side3)/2,Side3,Side3);
			g.FillRectangle((new SolidBrush(Color.FromArgb(rand.Next(256), rand.Next(256), rand.Next(256)))),(500-Side4)/2,(500-Side4)/2,Side4,Side4);
			g.FillRectangle((new SolidBrush(Color.FromArgb(rand.Next(256), rand.Next(256), rand.Next(256)))),(500-Side5)/2,(500-Side5)/2,Side5,Side5);
			g.FillRectangle((new SolidBrush(Color.FromArgb(rand.Next(256), rand.Next(256), rand.Next(256)))),(500-Side6)/2,(500-Side6)/2,Side6,Side6);
			g.FillRectangle((new SolidBrush(Color.FromArgb(rand.Next(256), rand.Next(256), rand.Next(256)))),(500-Side7)/2,(500-Side7)/2,Side7,Side7);
			g.FillRectangle((new SolidBrush(Color.FromArgb(rand.Next(256), rand.Next(256), rand.Next(256)))),(500-Side8)/2,(500-Side8)/2,Side8,Side8);
			g.FillRectangle((new SolidBrush(Color.FromArgb(rand.Next(256), rand.Next(256), rand.Next(256)))),(500-Side9)/2,(500-Side9)/2,Side9,Side9);
			g.FillRectangle((new SolidBrush(Color.FromArgb(rand.Next(256), rand.Next(256), rand.Next(256)))),(500-Side10)/2,(500-Side10)/2,Side10,Side10);
			
			

			


	
		}
	}
}
